class Celda {
    int fila;
    int columna;
    String valor;

    public Celda(int fila, int columna, String valor) {
        this.fila = fila;
        this.columna = columna;
        this.valor = valor;
    }
}
