
public class ej8 {

	public static void main(String[] args) {

		int i = 1;
		
		for ( i = 1 ; i <= 100 ; i++ ) {
			
			System.out.println(i);
			
		}
		
		
		
	}

}
