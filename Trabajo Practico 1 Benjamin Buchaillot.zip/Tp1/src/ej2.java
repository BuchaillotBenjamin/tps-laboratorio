import java.util.Scanner;
import javax.swing.JOptionPane;

public class ej2 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Ingree su nombre");
		 String nombre = sc.nextLine();
		 
		 System.out.println("bienvenido " + nombre);
		
		 
		 
		 
		 /*String nombre = JOptionPane.showInputDialog("Introduce tu nombre");
		 System.out.println("Bienvenido "+nombre);*/

		
		
		
		
		
		
	}

}
