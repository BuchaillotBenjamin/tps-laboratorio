
public class ej1 {

	public static void main(String[] args) {
		
	
		 String nombre = "Benja";
		 
		 System.out.println("bienvenido " + nombre);
	

	
	}
}
