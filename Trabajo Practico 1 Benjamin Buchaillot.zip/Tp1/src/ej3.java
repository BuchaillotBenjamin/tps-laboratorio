import java.util.Scanner;

public class ej3 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Ingree el primer numero");
		 int a = sc.nextInt();
		
		 System.out.println("Ingree el segundo numero");
		 int b = sc.nextInt();
		
		
		
		 System.out.println(" ");
		 System.out.println("suma= ");
		 System.out.println(a+b);
		 System.out.println(" ");
	
		 System.out.println("resta= ");
		 System.out.println(a-b);
		 System.out.println(" ");

		 System.out.println("multiplicacion= ");
		 System.out.println(a*b);
		 System.out.println(" ");
	
		 System.out.println("division= ");
		 System.out.println(a/b);
		 System.out.println(" ");
	
		 System.out.println("modulo= ");
		 System.out.println(a%b);
	
		 System.out.println(" fin ");
	
	
	
	
	
	}

}
