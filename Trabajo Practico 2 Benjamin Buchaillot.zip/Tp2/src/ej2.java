
public class ej2 {

	public static void main(String[] args) {
		
		//byte num = 1000 ;
		
		short num = 1000 ;
		
		System.out.println(num);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
