
public class ej6 {

	public static void main(String[] args) {
		
		String frase = "La lluvia en Mendoza es escasa";
		
		int numCaracteres = frase.length(); 
		
		System.out.println("El numero de caracteres de la frase: "+frase+". Es de: "+numCaracteres);
		
	}

}
