import java.util.Scanner;

public class ej12 {

	public static void main(String[] args) {
		
		Scanner leer = new Scanner(System.in);
		
		System.out.println("escriba una cadena, min 5 caracteres");
		
		String cadena = leer.nextLine();
		
		System.out.println(cadena.substring(3,5));
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
