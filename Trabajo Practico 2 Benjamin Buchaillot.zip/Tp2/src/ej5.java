import java.util.Scanner;

public class ej5 {

	public static void main(String[] args) {
		
		Scanner leer = new Scanner(System.in);
		
		System.out.println("digame un numero");
		
		int num = leer.nextInt();
		
		String numString = String.valueOf(num);
		
		System.out.println("int: "+num);
		
		System.out.println("String: "+numString);
		
		
		
		
		
		
		
		
		
		
		
	}

}
